<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="referrer" content="origin">
<meta name="fragment" content="!">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="/upload/favicon.ico" />
<link rel="stylesheet" href="reset.css"> <!-- RESET -->
<link rel="stylesheet" href="css.css"> <!-- Подключение стилей -->