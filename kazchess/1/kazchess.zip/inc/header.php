<header id="header">
    <section>
        <div class="header-up">
            <div class="logo">
                <img alt="logo" src="/upload/logo.svg" width="100px">
                <span class="logo-text">Делай в жизни правильные ходы!</span>
            </div>
            <div class="else">
                <div class="icons">
                    <div class="inst"><a href="#" class="no"></a></div>
                    <div class="fb"><a href="#" class="no"></a></div>
                    <div class="yt"><a href="#" class="no"></a></div>
                </div>
                <div class="search">
                    <input type="text" class="search-input" placeholder="Поиск по сайту">
                    <button class="search-button">
                        <span class="search-icon"></span>
                    </button>
                </div>
                <div class="auth" id="toggleButton">Авторизация</div>
                <div class="lang">RU
                    <div class="more-lang">
                        <a href="" class="no">KZ</a>
                        <a href="" class="no">EN</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-down">
            <div class="mobileonly">
                <div class="logo">
                    <img alt="logo" src="/upload/logo.svg" width="100px">
                    <span class="logo-text">Делай в жизни правильные ходы!</span>
                </div>
                <svg class="ham hamRotate ham8" id="ham" viewBox="0 0 100 100" width="80" id="toggleButton">
                    <path
                        class="line top"
                        d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20" />
                    <path
                        class="line middle"
                        d="m 30,50 h 40" />
                    <path
                        class="line bottom"
                        d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20" />
                </svg>
                <!--                  ДЛЯ МЕНЮ                  -->
                <script>
                    function toggleMenu() {
                        // Включаем анимацию бургера
                        document.getElementById('ham').classList.toggle('active');

                        // Открываем/закрываем подменю
                        var submenu = document.getElementById('header-mobile');
                        submenu.classList.toggle('active');

                        // Открываем/закрываем подменю
                        var submenu = document.getElementById('header');
                        submenu.classList.toggle('active');
                    }
                </script>
            </div>
        </div>
        <div class="header-mobile" id="header-mobile">
            <nav id="nav">
                <ul class="menu">
                    <li class="menu-item dropdown">Федерация&nbsp;<i></i>
                        <div class="submenu">
                            <a href="#">Деятельность</a>
                            <a href="#">Исполнительная дирекция</a>
                            <a href="#">Генеральный партнер</a>
                            <a href="#">Бюджет</a>
                            <a href="#">Документы</a>
                        </div>
                    </li>
                    <li class="menu-item dropdown">Турниры&nbsp;<i></i>
                        <div class="submenu">Список турниров</div>
                    </li>
                    <li class="menu-item dropdown">Спортсмены&nbsp;<i></i>
                        <div class="submenu">Список спортсменов</div>
                    </li>
                    <li class="menu-item dropdown">Социальные проекты&nbsp;<i></i>
                        <div class="submenu">Информация о проектах</div>
                    </li>
                    <li class="menu-item">Новости

                    </li>
                    <li class="menu-item">Контакты

                    </li>
                </ul>
                <!-- Выпадающий список, чтобы работало на iOS -->
                <script>
                    document.querySelectorAll('.menu-item').forEach(item => {
                        item.addEventListener('click', () => {
                            const submenu = item.querySelector('.submenu');
                            submenu.classList.toggle('active');
                        });
                    });
                </script>
            </nav>

            <div class="else">
                <div class="auth" onclick="togglePopup()">Авторизация
                </div>
                <!--  ЕСЛИ АВТОРИЗОВАН  -->
                <div class="auth_ready">
                    <img src="/upload/foto.png"><p>Kazachess ID: <strong>0 000 555</strong></p>
                </div>

                <div class="row-block">
                    <div class="icons">
                        <div class="inst"><a href="#" class="no"></a></div>
                        <div class="fb"><a href="#" class="no"></a></div>
                        <div class="yt"><a href="#" class="no"></a></div>
                    </div>
                    <div class="lang">
                        <span>RU</span>
                        <a href="" class="no"><span>KZ</span></a>
                        <a href="" class="no"><span>EN</span></a>
                    </div>
                </div>
                <div class="search">
                    <input type="text" class="search-input" placeholder="Поиск по сайту">
                    <button class="search-button">
                        <span class="search-icon"></span>
                    </button>
                </div>
            </div>
        </div>

    </section>





</header>

<!--   ПОПАП   -->
<div id="#popup" style="display: none;">
    тест
    <button onclick="togglePopup()">Закрыть</button>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var popup = document.getElementById('popup');
        var toggleButton = document.getElementById('toggleButton');
        var closeButton = document.getElementById('closeButton');

        toggleButton.onclick = function() {
            if (popup.style.display = 'none' || popup.style.display = '') {
                popup.style.display = 'block';
            } else {
                popup.style.display = 'none';
            }
        };

        closeButton.onclick = function() {
            popup.style.display = 'none';
        };
    });
</script>